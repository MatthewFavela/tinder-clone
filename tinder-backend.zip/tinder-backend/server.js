import express from 'express'
import mongoose from 'mongoose'
import cors from 'cors'
import Cards from './dbData.js'

const app = express()

const connectionUrl = 'mongodb+srv://admin:adminpassword@cluster0.fqunf.mongodb.net/tinderDB?retryWrites=true&w=majority'

mongoose.connect(connectionUrl, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useUnifiedTopology: true
})

const port = process.env.PORT || 8001
app.use(cors({origin: true}))

app.get('/', (req, res)=>{
    res.status(200).send('hello world')
})

app.post('/tinder/cards', (req, res)=>{
    const dbData = req.body

    Cards.Schema(dbData, (err, data)=>{
        if(err){
            res.status(500).send(err)
        }else{
            res.status(201).send(data)
        }
    })
})

app.get('/tinder/cards', (req, res)=>{

    Cards.find((err, data)=>{
        if(err){
            res.status(500).send(err)
        }else{
            res.status(200).send(data)
        }
    })
})

app.listen(port, ()=>{console.log('Now listening on port: '+ port)})